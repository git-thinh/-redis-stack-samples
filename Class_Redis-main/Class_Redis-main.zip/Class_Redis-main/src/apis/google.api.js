const googleApi = {
  firebase: {
    message: {
      sendSingleDevice: "/fcm/send",
    },
  },
};

module.exports = googleApi;
