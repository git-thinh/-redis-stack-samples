module.exports = {
  StatusCodes: require("../utils/statusCodes"),
  ReasonPhrases: require("../utils/reasonPhrases"),
};
