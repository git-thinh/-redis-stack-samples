module.exports = {
  RefetchToken: "refresh_token",
};
