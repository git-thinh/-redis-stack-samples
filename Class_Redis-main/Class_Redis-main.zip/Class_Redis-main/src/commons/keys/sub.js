module.exports = {
  SendEmail: "send:email",
  UserExit: "user:exit",
  AdminMaster: "tai*",
  AdminTopic: "dev.*",
  InTheSameAfter: "*2000",
  TopicAfter: "*.2000",
};
