module.exports = {
  User: "user",
};
