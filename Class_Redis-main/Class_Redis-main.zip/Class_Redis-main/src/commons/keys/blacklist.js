module.exports = {
  BlacklistTokens: "blacklist_tokens",
};
