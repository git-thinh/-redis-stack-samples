module.exports = {
  productKey: "product",
  countKey: "count",
  profileKey: "user_tai_dev",
};
