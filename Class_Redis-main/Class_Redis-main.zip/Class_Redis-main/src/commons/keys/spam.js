module.exports = {
  SpamForget: "spam_forget",
  SpamOTP: "spam_otp",
};
