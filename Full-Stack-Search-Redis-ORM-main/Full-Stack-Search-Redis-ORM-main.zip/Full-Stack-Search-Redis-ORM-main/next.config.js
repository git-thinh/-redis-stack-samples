module.exports = {
  env: {
    BASE_URL: process.env.BASE_URL,
    NEXT_PUBLIC_REDIS_URL: process.env.NEXT_PUBLIC_REDIS_URL,
    NEXT_PUBLIC_BASE_URL: process.env.BASE_URL,
  },
};
