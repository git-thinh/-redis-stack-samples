export default function (req, res) {
  res.status(200).json({ name: "Hello I'm Tài FullStack developer🔥" });
}
