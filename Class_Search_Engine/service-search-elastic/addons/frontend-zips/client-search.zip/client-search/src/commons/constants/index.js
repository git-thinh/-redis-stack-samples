const INDEX = {
  CAR_INFO: "car_info",
};

export { INDEX };
