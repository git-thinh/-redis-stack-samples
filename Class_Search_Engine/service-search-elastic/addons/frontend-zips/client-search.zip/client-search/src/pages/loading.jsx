const LoadingPage = () => {
  return <h1>LoadingPage</h1>;
};

export default LoadingPage;
