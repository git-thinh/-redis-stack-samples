const NotFoundPage = () => {
  return <h1>NotFoundPage</h1>;
};

export default NotFoundPage;
